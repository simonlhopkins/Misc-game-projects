class Player():
    def __init__(self, userName):
        self.userName=userName